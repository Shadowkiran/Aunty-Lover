// Entry point for the app
void main() => runApp(MyApp());